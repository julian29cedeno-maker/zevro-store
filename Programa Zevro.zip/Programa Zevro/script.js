/* ================= NAVEGACIÓN ================= */

function verProductos() {

    document.getElementById("tecnologia").scrollIntoView({
        behavior: "smooth"
    });

}


function irAContacto() {

    document.getElementById("contacto").scrollIntoView({
        behavior: "smooth"
    });

}


function irAPagos() {

    document.getElementById("pagos").scrollIntoView({
        behavior: "smooth"
    });

}


/* ================================================= */
/* ================= COMBOS ======================== */
/* ================================================= */

function abrirCombo(numero) {

    const modal = document.getElementById("modalCombo");

    const contenido = document.getElementById("contenidoCombo");

    let html = "";


    /* ================= COMBO 1 ================= */

    if (numero === 1) {

        html = `

            <span class="combo-number">
                COMBO 01
            </span>

            <h2>
                🔥 PRIMER COMBO ZEVRO
            </h2>

            <p>
                Presentamos nuestro <strong>primer combo</strong>,
                elaborado con prendas de <strong>excelente calidad</strong>,
                <strong>280 g de gramaje</strong> y
                <strong>100% algodón</strong>.
            </p>

            <p>
                Una combinación pensada para quienes buscan
                <strong>comodidad, durabilidad y un estilo premium.</strong>
            </p>

            <p>👕 <strong>Marca:</strong> Undergold</p>

            <p>🧵 <strong>Gramaje:</strong> 280 g</p>

            <p>🌿 <strong>Material:</strong> 100% algodón</p>

            <p class="modal-price">
                💰 Precio del combo: $120.000 COP
            </p>

            <p>
                🔥 <strong>
                ¡Llévate nuestro primer combo y eleva tu estilo con ZEVRO!
                </strong>
            </p>

            <a
                href="https://wa.me/573202748686?text=Hola%20ZEVRO,%20estoy%20interesado%20en%20el%20Primer%20Combo%20ZEVRO."
                target="_blank"
                class="modal-cta"
            >
                QUIERO ESTE COMBO
            </a>

        `;

    }


    /* ================= COMBO 2 ================= */

    else if (numero === 2) {

        html = `

            <span class="combo-number">
                COMBO 02
            </span>

            <h2>
                🔥 SEGUNDO COMBO ZEVRO
            </h2>

            <p>
                Presentamos nuestro <strong>segundo combo</strong>,
                elaborado con prendas de <strong>excelente calidad</strong>,
                <strong>280 g de gramaje</strong> y
                <strong>100% algodón</strong>.
            </p>

            <p>
                Una combinación pensada para quienes buscan
                <strong>comodidad, durabilidad y un estilo premium.</strong>
            </p>

            <p>👕 <strong>Marca:</strong> Undergold</p>

            <p>🧵 <strong>Gramaje:</strong> 280 g</p>

            <p>🌿 <strong>Material:</strong> 100% algodón</p>

            <p class="modal-price">
                💰 Precio del combo: Por confirmar
            </p>

            <p>
                🔥 <strong>
                ¡Llévate nuestro segundo combo y eleva tu estilo con ZEVRO!
                </strong>
            </p>

            <a
                href="https://wa.me/573202748686?text=Hola%20ZEVRO,%20estoy%20interesado%20en%20el%20Segundo%20Combo%20ZEVRO."
                target="_blank"
                class="modal-cta"
            >
                CONSULTAR COMBO
            </a>

        `;

    }


    /* ================= COMBO 3 ================= */

    else if (numero === 3) {

        html = `

            <span class="combo-number">
                COMBO 03
            </span>

            <h2>
                🔥 TERCER COMBO ZEVRO
            </h2>

            <p>
                Presentamos nuestro <strong>tercer combo</strong>,
                elaborado con prendas de <strong>excelente calidad</strong>,
                <strong>280 g de gramaje</strong> y
                <strong>100% algodón</strong>.
            </p>

            <p>
                Una combinación pensada para quienes buscan
                <strong>comodidad, durabilidad y un estilo premium.</strong>
            </p>

            <p>👕 <strong>Marca:</strong> Undergold</p>

            <p>🧵 <strong>Gramaje:</strong> 280 g</p>

            <p>🌿 <strong>Material:</strong> 100% algodón</p>

            <p class="modal-price">
                💰 Precio del combo: Por confirmar
            </p>

            <p>
                🔥 <strong>
                ¡Llévate nuestro tercer combo y eleva tu estilo con ZEVRO!
                </strong>
            </p>

            <a
                href="https://wa.me/573202748686?text=Hola%20ZEVRO,%20estoy%20interesado%20en%20el%20Tercer%20Combo%20ZEVRO."
                target="_blank"
                class="modal-cta"
            >
                CONSULTAR COMBO
            </a>

        `;

    }


    /* ================= COMBO 4 ================= */

    else if (numero === 4) {

        html = `

            <span class="combo-number">
                COMBO 04
            </span>

            <h2>
                🔥 CUARTO COMBO ZEVRO
            </h2>

            <p>
                Presentamos nuestro <strong>cuarto combo</strong>,
                elaborado con prendas de <strong>excelente calidad</strong>,
                <strong>280 g de gramaje</strong> y
                <strong>100% algodón</strong>.
            </p>

            <p>
                Una combinación pensada para quienes buscan
                <strong>comodidad, durabilidad y un estilo premium.</strong>
            </p>

            <p>👕 <strong>Marca:</strong> Undergold</p>

            <p>🧵 <strong>Gramaje:</strong> 280 g</p>

            <p>🌿 <strong>Material:</strong> 100% algodón</p>

            <p>
                👕 <strong>
                Puedes escoger 2 prendas de las que se encuentran disponibles.
                </strong>
            </p>

            <p class="modal-price">
                💰 Precio del combo: Por confirmar
            </p>

            <p>
                🔥 <strong>
                ¡Llévate nuestro cuarto combo y eleva tu estilo con ZEVRO!
                </strong>
            </p>

            <a
                href="https://wa.me/573202748686?text=Hola%20ZEVRO,%20estoy%20interesado%20en%20el%20Cuarto%20Combo%20ZEVRO."
                target="_blank"
                class="modal-cta"
            >
                CONSULTAR COMBO
            </a>

        `;

    }


    contenido.innerHTML = html;

    modal.style.display = "flex";

    document.body.style.overflow = "hidden";

}


/* ================= CERRAR MODAL ================= */

function cerrarCombo() {

    document.getElementById("modalCombo").style.display = "none";

    document.body.style.overflow = "auto";

}


/* ================= CERRAR HACIENDO CLICK AFUERA ================= */

window.addEventListener("click", function(event) {

    const modal = document.getElementById("modalCombo");

    if (event.target === modal) {

        cerrarCombo();

    }

});


/* ================= COPIAR NÚMERO ================= */

function copiarNumero(numero) {

    navigator.clipboard.writeText(numero)

        .then(function() {

            alert("Número copiado correctamente: " + numero);

        })

        .catch(function() {

            alert("No se pudo copiar el número.");

        });

}